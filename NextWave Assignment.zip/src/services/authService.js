import {
  generateTokens,
  verifyRefreshToken,
  hashPassword,
  comparePassword,
  hashRefreshToken,
  compareRefreshToken,
} from '../utils/jwt.js';
import {
  AuthenticationError,
  ConflictError,
  NotFoundError,
  ValidationError,
} from '../utils/errors.js';
import { AuthRepository } from '../repositories/authRepository.js';
import { OrganizationRepository } from '../repositories/organizationRepository.js';
import { USER_ROLES } from '../utils/constants.js';

export class AuthService {
  static async register(email, password, firstName, lastName, organizationName) {
    // Check if user already exists
    const existingUser = await AuthRepository.findUserByEmail(email);
    if (existingUser) {
      throw new ConflictError('Email already registered');
    }

    // Create organization
    const organization = await OrganizationRepository.createOrganization({
      name: organizationName,
    });

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user
    const user = await AuthRepository.createUser({
      email,
      password: hashedPassword,
      firstName,
      lastName,
      role: USER_ROLES.ADMIN,
      organizationId: organization.id,
    });

    // Generate tokens
    const tokens = generateTokens(user.id);

    // Store refresh token
    const hashedRefreshToken = await hashRefreshToken(tokens.refreshToken);
    const refreshTokenId = await AuthRepository.storeRefreshToken(
      user.id,
      hashedRefreshToken,
      new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
    );

    return {
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        organizationId: user.organizationId,
      },
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    };
  }

  static async login(email, password) {
    const user = await AuthRepository.findUserByEmail(email);
    if (!user) {
      throw new AuthenticationError('Invalid email or password');
    }

    const isPasswordValid = await comparePassword(password, user.password);
    if (!isPasswordValid) {
      throw new AuthenticationError('Invalid email or password');
    }

    const tokens = generateTokens(user.id);

    // Revoke prior refresh tokens to enforce single valid refresh token per user
    await AuthRepository.revokeAllUserTokens(user.id);

    // Store new refresh token
    const hashedRefreshToken = await hashRefreshToken(tokens.refreshToken);
    await AuthRepository.storeRefreshToken(
      user.id,
      hashedRefreshToken,
      new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
    );

    return {
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        organizationId: user.organizationId,
      },
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    };
  }

  static async refreshAccessToken(refreshToken) {
    const decoded = verifyRefreshToken(refreshToken);
    if (!decoded) {
      throw new AuthenticationError('Invalid or expired refresh token');
    }

    const tokenRecord = await AuthRepository.findRefreshTokenByUserId(decoded.userId);
    if (!tokenRecord || tokenRecord.revokedAt) {
      throw new AuthenticationError('Refresh token has been revoked');
    }

    const isTokenValid = await compareRefreshToken(
      refreshToken,
      tokenRecord.hashedToken
    );
    if (!isTokenValid) {
      throw new AuthenticationError('Invalid refresh token');
    }

    const user = await AuthRepository.findUserById(decoded.userId);
    if (!user) {
      throw new NotFoundError('User not found');
    }

    // Revoke old token
    await AuthRepository.revokeRefreshToken(tokenRecord.id);

    // Generate new tokens
    const newTokens = generateTokens(user.id);
    const hashedNewRefreshToken = await hashRefreshToken(newTokens.refreshToken);
    await AuthRepository.storeRefreshToken(
      user.id,
      hashedNewRefreshToken,
      new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
    );

    return {
      accessToken: newTokens.accessToken,
      refreshToken: newTokens.refreshToken,
    };
  }

  static async logout(userId) {
    await AuthRepository.revokeAllUserTokens(userId);
    return { message: 'Logged out successfully' };
  }
}
